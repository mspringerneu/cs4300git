package cs4300.assignment1;

/**
 * Created by mspringer on 9/26/16.
 */
public class Tower {
    int maxDisks;
}
